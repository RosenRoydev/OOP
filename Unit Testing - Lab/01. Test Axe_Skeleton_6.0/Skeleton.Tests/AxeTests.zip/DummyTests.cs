﻿using NUnit.Framework;
using System;

namespace Skeleton.Tests
{
    [TestFixture]
    public class DummyTests
    {
        [Test]
        public void DummyConstructorShouldworksCorectly()
        {
            int health = 30;
            int experience = 50;

            Dummy dummy = new(30, 50);
            Assert.AreEqual(health, dummy.Health);
            Assert.AreEqual(experience, 50);
        }

        [Test]
        public void TakeAttackMethodShoulWorksCorectly()
        {
            Dummy dummy = new(30, 50);
            Axe axe = new(20, 30);

            dummy.TakeAttack(axe.AttackPoints);

            int expectedHealth = 10;
            Assert.AreEqual(expectedHealth, dummy.Health);


        }

        [Test]
        public void TakeAttackMethodShouldThrowsExceptionWhenHealthIsZeroOrLower()
        {
            Dummy dummy = new(0, 50);
            Axe axe = new(30, 30);



            Assert.Throws<InvalidOperationException>(() => dummy.TakeAttack(axe.AttackPoints), "Dummy is dead.");
        }

        [Test]
        public void MethodGuveExperienceShoulWorksCorectly()
        {
            Dummy dummy = new(-1, 50);

            dummy.GiveExperience();

            int expectedexperience = 50;

            Assert.AreEqual(expectedexperience, 50);
        }
        [Test]
        public void MethodGiveExperienceShoulthrowsExceptionWhenDummyIsNotDead()
        {
            Dummy dummy = new(20, 62);

            Assert.Throws<InvalidOperationException>(() => dummy.GiveExperience(), "Target is not dead.");
        }
        [Test]
        public void MethodIsDeadShouldreturnTrueIfDummyHelthIsZeoroOrLessZero()
        {
            Dummy dummy = new Dummy(-2, 40);
            

            Assert.IsTrue(dummy.IsDead()); 
        }

    } 
}