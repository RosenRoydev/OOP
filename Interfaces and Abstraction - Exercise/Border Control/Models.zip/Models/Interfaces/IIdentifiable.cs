﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Border_Control.Models.Interfaces
{
    internal interface IIdentifiable
    {
        public String Id { get; }
    }
}
