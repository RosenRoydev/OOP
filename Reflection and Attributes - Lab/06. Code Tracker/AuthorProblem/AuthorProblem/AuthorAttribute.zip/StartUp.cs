﻿namespace AuthorProblem
{
    public class StartUp
    {
        static void Main(string[] args)
        {
            [Author("George")]
            static void Main(string[] args)
            {
                var tracker = new Tracker();
                tracker.PrintMethodsByAuthor();

            }

        }
    }
}
    

